# dbpigeon

[![ci](https://github.com/techmindpartners/dbpigeon-agent/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/techmindpartners/dbpigeon-agent/actions/workflows/ci.yml)

---

<div align="center">

![iggy](assets/dbpigeon.png)

</div>

---

## Project Overview
**dbpigeon** is a Rust-based database monitoring agent designed to collect and analyze database metrics. The project aims to follow Rust best practices with a focus on safety, performance, and reliability while providing a scalable solution for database monitoring operations.

Here are the key architectural features of the project:

### Modular Design
- Separate modules for collection, monitoring, export, and configuration
- Uses a plugin-based architecture for database engine support
- Currently focused on PostgreSQL with plans for MSSQL and MongoDB support

### Configuration Management
- Uses TOML-based configuration
- Supports multiple monitoring targets
- Configurable logging levels and monitoring intervals
- API configuration for data export

Sample configuration:
```toml
[agent]
api_base_url = "https://api.dbpigeon.com"
api_key = "[your_api_key]"
log_level = "[debug, info, warn, error]"
high_frequency_interval = [10, 30, 60] # default 10 secs
medium_frequency_interval = [60, 120, 300] # default 1 min
low_frequency_interval = [600, 900, 1800] # default 10 mins

[targets.server1]
platform = "[self-hosted, aws, gcp, azure, huawei, heroku]"
db_engine = "[postgresql, mssql, mongodb]"
db_host = "[hostname]"
db_port = "[port]"
db_username = "[username]"
db_password = "[password]"
db_name = "[database_name]"
```

### Monitoring System
Implements three monitoring frequency tiers:
- High Frequency (10s): Critical metrics, active sessions
- Medium Frequency (1m): Table stats, index usage
- Low Frequency (10m): Schema configuration, system metrics

### Async Architecture
- Built on `tokio` async runtime
- Implements concurrent monitoring operations
- Uses async/await for I/O operations
- Employs thread pools for parallel execution

### Data Export
- RESTful API-based data transmission
- Implements compression and batching
- Includes retry mechanisms with backoff
- Secure authentication system

### Error Handling & Logging
- Comprehensive error handling using Rust's Result types
- Configurable logging system with dynamic log levels
- Structured logging for better observability

### Graceful Shutdown
- Signal handling (SIGTERM, SIGINT)
- Controlled shutdown sequence
- Ensures data preservation during shutdown

### DataFlow Diagram
- The following diagram illustrates the data flow within the agent:

<div align="center">

![data-flow](docs/data-flow-mermaid.png)

</div>

### Docker Build 
```bash
docker build -t dbpigeon-agent:latest -f Dockerfile .
```
```bash
docker run -d \
  --name dbpigeon-agent \
  -e CONFIG_FILE="/app/examples/self-hosted-target.toml" \
  dbpigeon-agent:latest
```
